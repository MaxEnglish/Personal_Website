import React from 'react';
import '../resume.css'

export default function Resume() {
    return (
        <div className='resume-backing'>
            <img className="resume-obj" src='resume.jpg'></img>
        </div>
    )
}