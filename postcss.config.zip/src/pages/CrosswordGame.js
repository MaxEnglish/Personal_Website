import React from 'react';
import Puzzle from '../Crossword/components-crossword/Puzzle';

export default function ScrabbleGame () {
    return (
     <>
        <Puzzle />
     </>   
    )
}